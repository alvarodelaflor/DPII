package methods;

/**
 * Hello world!
 *
 */
public class generateUserAccountAuditorCreditCard 
{
    public static void main( String[] args )
    {
    	Integer res = 0;
    	Integer loops = 20;
    	Integer numberOfUser = 190;
    	System.out.println(
    	"<bean id=\"curricula11\" class=\"domain.Curricula\">\n"
    	+
    	"	<property name=\"name\" value=\"Cleaner 1 Curriculum\" />\n"
    	+ 
    	"	<property name=\"statement\" value=\"Statement Curriculum 1 Cleaner 1\" />\n"
    	+ 
    	"	<property name=\"phone\" value=\"123456789\" />\n"
    	+ 
    	"	<property name=\"linkLinkedin\" value=\"https://www.linkedin.com/in/francisco-batista-n%C3%BA%C3%B1ez-336442172/\" />\n"
    	+ 
    	"	<property name=\"bannerLogo\" value=\"https://www.bannerlogo.com\" />\n"
    	+ 
    	"	<property name=\"isCopy\" value=\"false\" />\n"
    	+ 
    	"	<property name=\"cleaner\" ref=\"cleaner01\" />\n"
    	+ 
    	"</bean>\n"
    	);
    	while (res < (loops*numberOfUser)) {
			System.out.println(generaAdmin(res));
			res++;
		}
    }
    
    private static String generaAdmin(Integer num) {
    	String res = "";
    	res = 
    	"<bean id=\"autoEducationalData" + num + "\" class=\"domain.EducationalData\">\n"
    	+
    	"	<property name=\"degree\" value=\"Degree" + num + "\" />\n"
    	+
    	"	<property name=\"institution\" value=\"ETSII\" />\n"
    	+
    	"	<property name=\"mark\" value=\"A++\" />\n"
    	+
    	"	<property name=\"startDate\" value=\"2019/12/12 21:00\" />\n"
    	+
    	"	<property name=\"endDate\" value=\"2019/12/12 21:05\" />\n"
    	+
    	"	<property name=\"curricula\" ref=\"curricula11\" />\n"
    	+
    	"	<property name=\"isCopy\" value=\"false\" />\n"
    	+
    	"</bean>\n"
    	+
    	"\n"
    	;
    	return res;
    }
}
