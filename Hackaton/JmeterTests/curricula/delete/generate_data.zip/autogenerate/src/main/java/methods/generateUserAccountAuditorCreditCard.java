package methods;

/**
 * Hello world!
 *
 */
public class generateUserAccountAuditorCreditCard 
{
    public static void main( String[] args )
    {
    	Integer res = 0;
    	Integer loops = 20;
    	Integer numberOfUser = 80;
    	while (res < (loops*numberOfUser)) {
			System.out.println(generaAdmin(res));
			res++;
		}
    }
    
    private static String generaAdmin(Integer num) {
    	String res = "";
    	res = 
    	"<bean id=\"autoCurricula" + num + "\" class=\"domain.Curricula\">\n"
    	+
    	"	<property name=\"name\" value=\"Cleaner 1 Curriculum" + num + "\" />\n"
    	+
    	"	<property name=\"statement\" value=\"Statement Curriculum 1 Cleaner 1\" />\n"
    	+
    	"	<property name=\"phone\" value=\"123456789\" />\n"
    	+
    	"	<property name=\"linkLinkedin\" value=\"https://www.linkedin.com/in/francisco-batista-n%C3%BA%C3%B1ez-336442172\" />\n"
    	+
    	"	<property name=\"bannerLogo\" value=\"https://www.bannerlogo.com\" />\n"
    	+
    	"	<property name=\"isCopy\" value=\"false\" />\n"
    	+
    	"	<property name=\"cleaner\" ref=\"cleaner01\" />\n"
    	+
    	"</bean>\n"
    	+
    	"\n"
    	;
    	return res;
    }
}
