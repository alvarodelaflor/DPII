package aa.aa;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Integer res = 0;
    	while (res < 2800) {
			System.out.println(generaAdmin(res));
			res++;
		}
    }
    
    private static String generaAdmin(Integer num) {
    	String res = "";
    	res = 
    	"<bean id=\"socialProfileId" + num + "\" class=\"domain.SocialProfile\">\n"
    	+
    	"	<property name=\"nick\" value=\"Alias\" />\n"
    	+
        "	<property name=\"link\" value= \"https://www.google.com/\"/>\n"
    	+
        "	<property name=\"name\" value=\"My red\"/>\n"
    	+
        "	<property name=\"actor\" ref=\"hacker01\"/>\n"
    	+
    	"</bean>\n"
    	;
    	return res;
    }
}
