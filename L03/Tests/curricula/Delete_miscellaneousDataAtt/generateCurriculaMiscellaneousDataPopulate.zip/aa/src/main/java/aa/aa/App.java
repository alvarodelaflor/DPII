package aa.aa;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Integer res = 0;
    	while (res < 8448) {
			System.out.println(generaAdmin(res));
			res++;
		}
    }
    
    private static String generaAdmin(Integer num) {
    	String res = "";
    	res = 
    	"<bean id=\"miscellaneousAttachment" + num + "\" class=\"domain.MiscellaneousAttachment\">\n"
    	+
    	"	<property name=\"attachment\" value=\"Tengo valia\" />\n"
    	+
        "	<property name=\"curriculaM\" ref= \"curricula01\"/>\n"
    	+
        "	<property name=\"isCopy\" value=\"false\"/>\n"
    	+
    	"</bean>\n"
    	;
    	return res;
    }
}
