package aa.aa;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Integer res = 0;
    	while (res < 2250) {
			System.out.println(generaAdmin(res));
			res++;
		}
    }
    
    private static String generaAdmin(Integer num) {
    	String res = "";
    	res = 
    	"<bean id=\"educationalData" + num + "\" class=\"domain.EducationalData\">\n"
    	+
    	"	<property name=\"degree\" value=\"Bachillerato de Ciencias y Tecnologia\" />\n"
    	+
    	"	<property name=\"institution\" value=\"IES Blas Infante\" />\n"
    	+
		"	<property name=\"mark\" value=\"A+\" />\n"
    	+
		"	<property name=\"startDate\" value=\"2016/12/12 21:00\" />\n"
    	+
        "	<property name=\"endDate\" value=\"2018/12/12 21:00\" />\n"
    	+
        "	<property name=\"curricula\" ref= \"curricula01\"/>\n"
    	+
        "	<property name=\"isCopy\" value=\"false\"/>\n"
    	+
    	"</bean>\n"
    	;
    	return res;
    }
}
