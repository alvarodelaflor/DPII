package aa.aa;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Integer res = 0;
    	while (res < 4800) {
			System.out.println(generaAdmin(res));
			res++;
		}
    }
    
    private static String generaAdmin(Integer num) {
    	String res = "";
    	res = 
    	"<bean id=\"positionData" + num + "\" class=\"domain.PositionData\">\n"
    	+
    	"	<property name=\"title\" value=\"Work 1\" />\n"
    	+
    	"	<property name=\"description\" value=\"description1\" />\n"
    	+
		"	<property name=\"startDate\" value=\"2016/12/12 21:00\" />\n"
    	+
        "	<property name=\"endDate\" value=\"2018/12/12 21:00\" />\n"
    	+
        "	<property name=\"curricula\" ref= \"curricula01\"/>\n"
    	+
        "	<property name=\"position\" ref= \"position01\"/>\n"
    	+
        "	<property name=\"isCopy\" value=\"false\"/>\n"
    	+
    	"</bean>\n"
    	;
    	return res;
    }
}
