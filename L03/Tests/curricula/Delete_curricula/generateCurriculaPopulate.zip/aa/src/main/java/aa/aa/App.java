package aa.aa;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Integer res = 0;
    	while (res < 7000) {
			System.out.println(generaAdmin(res));
			res++;
		}
    }
    
    private static String generaAdmin(Integer num) {
    	String res = "";
    	res = 
    	"<bean id=\"curricula" + num + "\" class=\"domain.Curricula\">\n"
    	+
    	"	<property name=\"name\" value=\"name01\" />\n"
    	+
    	"	<property name=\"statement\" value=\"statement01\" />\n"
    	+
		"	<property name=\"phone\" value=\"123456\" />\n"
    	+
		"	<property name=\"linkGitHub\" value=\"https://linkGitHub01\" />\n"
    	+
        "	<property name=\"linkLinkedin\" value=\"https://linkLinkedin01\" />\n"
    	+
        "	<property name=\"miscellaneous\" value= \"miscellaneous01\"/>\n"
    	+
        "	<property name=\"hacker\" ref= \"hacker01\"/>\n"
    	+
        "	<property name=\"isCopy\" value=\"false\"/>\n"
    	+
    	"</bean>\n"
    	;
    	return res;
    }
}
