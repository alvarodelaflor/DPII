package methods;

/**
 * Hello world!
 *
 */
public class generatePosition 
{
    public static void main( String[] args )
    {
    	Integer res = 0;
    	Integer numberOfUser = 70;
    	Integer numberOfLoops = 10;
    	while (res < (numberOfUser * numberOfLoops) ) {
			System.out.println(generaAdmin(res));
			res++;
		}
    }
    
    private static String generaAdmin(Integer num) {
    	String res = "";
    	res = 
    	"<bean id=\"autoPosition" + num + "\" class=\"domain.Position\">\n"
    	+
    	"	<property name=\"ticker\" value=\"AUTO-" + num + "\" />\n"
    	+
    	"	<property name=\"title\" value=\"title-" + num + "\" />\n"
    	+
    	"	<property name=\"techs\" value=\"techs" + num + "\" />\n"
    	+
    	"	<property name=\"status\" value=\"true\" />\n"
    	+
    	"	<property name=\"skills\" value=\"skills\" />\n"
    	+
    	"	<property name=\"salary\" value=\"20.0\" />\n"
    	+
    	"	<property name=\"profile\" value=\"profile01\" />\n"
    	+
    	"	<property name=\"description\" value=\"description01\" />\n"
    	+
    	"	<property name=\"deadline\" value=\"2020/11/10 08:00\" />\n"
    	+
    	"	<property name=\"company\" ref=\"company01\" />\n"
    	+
    	"	<property name=\"cancel\" value=\"false\" />\n"
    	+
    	"</bean>\n"
    	+
    	"<bean id=\"autoAudit" + num + "\" class=\"domain.Audit\">\n"
    	+
    	"	<property name=\"creationMoment\" value=\"2019/01/10 08:00" + "\" />\n"
    	+
    	"	<property name=\"text\" value=\"Texto de prueba -" + num + "\" />\n"
    	+
    	"	<property name=\"score\" value=\"7\" />\n"
    	+
    	"	<property name=\"status\" value=\"false\" />\n"
    	+
    	"	<property name=\"auditor\" ref=\"auditor01\" />\n"
    	+
    	"	<property name=\"position\" ref=\"autoPosition" + num + "\" />\n"
    	+
    	"</bean>\n"
    	;
    	return res;
    }
}
