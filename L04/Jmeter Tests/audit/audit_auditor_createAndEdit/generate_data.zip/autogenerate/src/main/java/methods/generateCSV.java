package methods;

public class generateCSV {

	public static void main(String[] args) {
		int numberOfUser = 2;
		int numberOfLoops = 5;
		int i = 0;
		while (i<numberOfUser) {
			int j = 0;
			while (j < numberOfLoops) {
				System.out.println(i);
				j++;
			}
			i++;	
		}

	}

}
