package methods;

/**
 * Hello world!
 *
 */
public class generateUserAccountAuditorCreditCard 
{
    public static void main( String[] args )
    {
    	Integer res = 0;
    	Integer numberOfUser = 220;
    	while (res < numberOfUser) {
			System.out.println(generaAdmin(res));
			res++;
		}
    }
    
    private static String generaAdmin(Integer num) {
    	String res = "";
    	res = 
    	"<bean id=\"autoUserAccount" + num + "\" class=\"security.UserAccount\">\n"
    	+
    	"	<property name=\"username\" value=\"auditor" + num + "\" />\n"
    	+
    	"	<property name=\"password\" value=\"f7d07071ed9431ecae3a8d45b4c82bb2\" />\n"
    	+
		"	<property name=\"authorities\" >\n"
    	+
		"		<list>\n"
    	+
        "			<bean class=\"security.Authority\">\n"
    	+
        "				<property name=\"authority\" value= \"AUDITOR\"/>\n"
    	+
		"			</bean>\n"
    	+
		"		</list>\n"
    	+
        "	</property>\n"
    	+
    	"</bean>\n"
    	+
    	"\n"
    	+
    	"<bean id=\"autoCreditCard" + num + "\" class=\"domain.CreditCard\">\n"
    	+
    	"	<property name=\"holder\" value=\"Alvaro de la Flor Bonilla" + num + "\" />\n"
    	+
    	"	<property name=\"make\" value=\"VISA\" />\n"
    	+
    	"	<property name=\"number\" value=\"1234567891234567\" />\n"
    	+
    	"	<property name=\"CVV\" value=\"234\" />\n"
    	+
    	"	<property name=\"expiration\" value=\"22/10\" />\n"
    	+
    	"</bean>\n"
    	+
    	"\n"
    	+
    	"<bean id=\"autoAuditor" + num + "\" class=\"domain.Auditor\">\n"
    	+
    	"	<property name=\"name\" value=\"auditor" + num + "\" />\n"
    	+
    	"	<property name=\"surname\" value=\"surname" + num + "\" />\n"
    	+
    	"	<property name=\"photo\" value=\"https://www.photolog.es?id=" + num + "\" />\n"
    	+
    	"	<property name=\"email\" value=\"alvarodelaflor@gmail.com" + num + "\" />\n"
    	+
    	"	<property name=\"phone\" value=\"665381123\" />\n"
    	+
    	"	<property name=\"address\" value=\"La luna\" />\n"
    	+
    	"	<property name=\"userAccount\" ref=\"autoUserAccount" + num + "\" />\n"
    	+
    	"	<property name=\"creditCard\" ref=\"autoCreditCard" + num + "\" />\n"
    	+
    	"	<property name=\"vatNumber\" value=\"Es12345678s\" />\n"
    	+
    	"</bean>\n"
    	;
    	return res;
    }
}
